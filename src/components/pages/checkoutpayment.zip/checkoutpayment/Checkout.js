import React from "react";
import OrderDetailsPage from "../orderpage/OrderDetailsPage";
import Checkoutpayment1 from "./CheckoutPayment";


export const CheckoutPage=()=> {
  return (
    <>
        <OrderDetailsPage />
        <Checkoutpayment1 />
    </>
  );
  }