import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';
import Container from 'react-bootstrap/Container';


export const Checkoutpayment1= () => {
    const [validated, setValidated] = useState(false);
  
    const handleSubmit = (event) => {
      const form = event.currentTarget;
      if (form.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      }
  
      setValidated(true);
    };
  
    return (
        <Container>
      <Form noValidate validated={validated} onSubmit={handleSubmit}>
        <Row className="mb-3">
          <h3>Customer Details</h3>
        <Form.Group md="8" controlId="validationCustom01">
            <Form.Label>Email Address</Form.Label>
            <Form.Control
              required
              type="text"
              placeholder="Email Address"
            />
            <br />
          </Form.Group>

          <Form.Group as={Col} md="6" controlId="validationCustom01">
            <Form.Label>First Name</Form.Label>
            <Form.Control
              required
              type="text"
              placeholder="First name"
            />
            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
          </Form.Group>


          <Form.Group as={Col} md="6" controlId="validationCustom02">
            <Form.Label>Last Name</Form.Label>
            <Form.Control
              required
              type="text"
              placeholder="Last name"
            />
            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
          </Form.Group>

          </Row>
        <Row className="mb-3">
          <Form.Group as={Col} md="6" controlId="validationCustom03">
            <Form.Label>Select Region</Form.Label>
            <Form.Select aria-label="Default select example">
      <option>Select Region from list</option>
      <option value="1">Australia</option>
      <option value="2">North America</option>
      <option value="3">Bahrain</option>
      <option value="3">India</option>
      <option value="3">Belarus</option>
    </Form.Select>
          </Form.Group>

          <Form.Group as={Col} md="6" controlId="validationCustom02">
            <Form.Label>Phone Number</Form.Label>
            <Form.Control
              required
              type="number"
              placeholder="Phone Number"
            />
          </Form.Group>

          {/* <Form.Group as={Col} md="4" controlId="validationCustomUsername">
            <Form.Label>Username</Form.Label>
            <InputGroup hasValidation>
              <InputGroup.Text id="inputGroupPrepend">@</InputGroup.Text>
              <Form.Control
                type="text"
                placeholder="Username"
                aria-describedby="inputGroupPrepend"
                required
              />
              <Form.Control.Feedback type="invalid">
                Please choose a username.
              </Form.Control.Feedback>
            </InputGroup>
          </Form.Group> */}


        </Row>
        <Row className="mb-3">
          <Form.Group as={Col} md="6" controlId="validationCustom03">
            <Form.Label>Select State</Form.Label>
            <Form.Select aria-label="Default select example">
      <option>Select State from list</option>
      <option value="1">Andhra Pradesh</option>
      <option value="2">Arunachal Pradesh</option>
      <option value="3">Assam</option>
      <option value="3">Bihar</option>
      <option value="3">Chhatisgarh</option>
      <option value="3">Goa</option>
      <option value="3">Gujrat</option>
      <option value="3">Haryana</option>
      <option value="3">Himachal Pradesh</option>
      <option value="3">Jharkhand</option>
      <option value="3">Karnataka</option>
      <option value="3">Kerala</option>
      <option value="3">Madhya Pradesh</option>
      <option value="3">Maharashtra</option>
      <option value="3">Manipur</option>
      <option value="3">Meghalaya</option>
      <option value="3">Mizoram</option>
      <option value="3">Nagaland</option>
      <option value="3">Odisha</option>
      <option value="3">Punjab</option>
      <option value="3">Rajasthan</option>
      <option value="3">Sikkim</option>
      <option value="3">Tamil Nadu</option>
      <option value="3">Telangana</option>
      <option value="3">Tripura</option>
      <option value="3">Uttar Pradesh</option>
      <option value="3">Uttarakhand</option>
      <option value="3">West Bengal</option>
    </Form.Select>
          </Form.Group>


          <Form.Group as={Col} md="3" controlId="validationCustom04">
            <Form.Label>City</Form.Label>
            <Form.Control type="text" placeholder="Enter City"  required />
            <Form.Control.Feedback type="invalid">
              Please provide a valid City.
            </Form.Control.Feedback>
          </Form.Group>


          <Form.Group as={Col} md="3" controlId="validationCustom05">
            <Form.Label>Postal Code</Form.Label>
            <Form.Control type="number" placeholder="Postal Code" required />
            <Form.Control.Feedback type="invalid">
              Please provide a valid zip.
            </Form.Control.Feedback>
          </Form.Group>
        </Row>

          <Form.Group className="mb-3">
            <Form.Check
              label="Save this information for next time"
            />
          </Form.Group>


          <Form.Group as={Col} md="8" controlId="validationCustom04">
            <Form.Label><h3>Payment Method</h3></Form.Label> 
            <div><input type="radio" label='Standard' value="std"/> <h6>Standard (Delivery Expected in 2-3 hours)</h6></div>
            <div><input type="radio" label='Express' value="exp"/> <h6>Express (Guaranteed Delivery in Half an hour)</h6></div>
          </Form.Group>
            <br />

        <Button type="submit">Continue to Payment</Button>
      </Form>
      </Container>



    );
  }

  //export default Checkoutpayment1;